﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class UPDATEMEMBER

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    'UPDATE FORM LOAD'
    Private Sub UPDATEMEMBER_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LISDataSet.MEMBERINFO' table. You can move, or remove it, as needed.
        Me.MEMBERINFOTableAdapter.Fill(Me.LISDataSet.MEMBERINFO)
        con.ConnectionString = "Data Source=DESKTOP-3MAL78A\SQLEXPRESS01;Initial Catalog=LIS;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        Label2.Enabled = False
        Label3.Enabled = False
        Label4.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        ComboBox1.Enabled = False

    End Sub

    'DISPLAYS DATABASE' 
    Public Sub display_data()

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * FROM MEMBERINFO where MEMBERID =" + TextBox1.Text + ""
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    'UPDATE BUTTON'
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE MEMBERINFO set MEMBERNAME ='" + TextBox2.Text + "', PHONENUMBER ='" + TextBox3.Text + "',PLACE='" + ComboBox1.SelectedItem + "' WHERE MEMBERID =" + TextBox1.Text + ""
        cmd.ExecuteNonQuery()
        MessageBox.Show("MEMBER RECORD HAS BEEN UPDATED")
        display_data()


    End Sub

    'TEXTBOX1 ID SEARCH'
    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox1.TextChanged

        Label2.Enabled = True
        Label3.Enabled = True
        Label4.Enabled = True
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        ComboBox1.Enabled = True
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * FROM MEMBERINFO WHERE MEMBERID ='" + TextBox1.Text + "'"
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        DataGridView1.DataSource = dt
        If dt.Rows.Count() > 0 Then

            TextBox2.Text = dt.Rows(0)(1).ToString()
            TextBox3.Text = dt.Rows(0)(2).ToString()
            ComboBox1.SelectedItem = dt.Rows(0)(3).ToString()

        ElseIf TextBox1.Text <> Nothing Then

            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            ComboBox1.SelectedIndex = -1
            MessageBox.Show("NO SUCH ID FOUND")

        End If

    End Sub

    'CANCEL BUTTON'
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Me.Hide()
        Dim frm As New LIBRARYINFORMATION
        frm.Show()

    End Sub

End Class