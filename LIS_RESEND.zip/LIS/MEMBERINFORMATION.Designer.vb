﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MEMBERINFORMATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.MEMBERID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MEMBERNAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PHONENUMBER = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PLACEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MEMBERINFOBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LISDataSet = New LIS.LISDataSet()
        Me.MEMBERINFOTableAdapter = New LIS.LISDataSetTableAdapters.MEMBERINFOTableAdapter()
        Me.Button4 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MEMBERINFOBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LISDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.MintCream
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Button3.Location = New System.Drawing.Point(713, 394)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(198, 37)
        Me.Button3.TabIndex = 8
        Me.Button3.Text = "CANCEL"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.MintCream
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Button2.Location = New System.Drawing.Point(249, 394)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(198, 37)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "DELETE A RECORD"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.MintCream
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Button1.Location = New System.Drawing.Point(12, 394)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(195, 37)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "UPDATE A RECORD"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.MEMBERID, Me.MEMBERNAME, Me.PHONENUMBER, Me.PLACEDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.MEMBERINFOBindingSource
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridView1.Location = New System.Drawing.Point(12, 12)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(899, 354)
        Me.DataGridView1.TabIndex = 5
        '
        'MEMBERID
        '
        Me.MEMBERID.DataPropertyName = "MEMBERID"
        Me.MEMBERID.HeaderText = "MEMBER ID"
        Me.MEMBERID.Name = "MEMBERID"
        Me.MEMBERID.Width = 110
        '
        'MEMBERNAME
        '
        Me.MEMBERNAME.DataPropertyName = "MEMBERNAME"
        Me.MEMBERNAME.HeaderText = "MEMBER NAME"
        Me.MEMBERNAME.Name = "MEMBERNAME"
        Me.MEMBERNAME.Width = 280
        '
        'PHONENUMBER
        '
        Me.PHONENUMBER.DataPropertyName = "PHONENUMBER"
        Me.PHONENUMBER.HeaderText = "PHONE NUMBER"
        Me.PHONENUMBER.Name = "PHONENUMBER"
        Me.PHONENUMBER.Width = 160
        '
        'PLACEDataGridViewTextBoxColumn
        '
        Me.PLACEDataGridViewTextBoxColumn.DataPropertyName = "PLACE"
        Me.PLACEDataGridViewTextBoxColumn.HeaderText = "PLACE"
        Me.PLACEDataGridViewTextBoxColumn.Name = "PLACEDataGridViewTextBoxColumn"
        Me.PLACEDataGridViewTextBoxColumn.Width = 180
        '
        'MEMBERINFOBindingSource
        '
        Me.MEMBERINFOBindingSource.DataMember = "MEMBERINFO"
        Me.MEMBERINFOBindingSource.DataSource = Me.LISDataSet
        '
        'LISDataSet
        '
        Me.LISDataSet.DataSetName = "LISDataSet"
        Me.LISDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MEMBERINFOTableAdapter
        '
        Me.MEMBERINFOTableAdapter.ClearBeforeFill = True
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.MintCream
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Button4.Location = New System.Drawing.Point(484, 394)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(198, 37)
        Me.Button4.TabIndex = 9
        Me.Button4.Text = "MEMBER REPORT"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'MEMBERINFORMATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Indigo
        Me.ClientSize = New System.Drawing.Size(923, 507)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "MEMBERINFORMATION"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MEMBER INFORMATION"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MEMBERINFOBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LISDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents LISDataSet As LIS.LISDataSet
    Friend WithEvents MEMBERINFOBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MEMBERINFOTableAdapter As LIS.LISDataSetTableAdapters.MEMBERINFOTableAdapter
    Friend WithEvents MEMBERIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MEMBERNAMEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PHONENUMBERDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MEMBERID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MEMBERNAME As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PHONENUMBER As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PLACEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Button4 As System.Windows.Forms.Button
End Class
