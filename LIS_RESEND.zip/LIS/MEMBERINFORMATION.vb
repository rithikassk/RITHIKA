﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class MEMBERINFORMATION

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub MEMBERINFORMATION_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LISDataSet.MEMBERINFO' table. You can move, or remove it, as needed.
        Me.MEMBERINFOTableAdapter.Fill(Me.LISDataSet.MEMBERINFO)
        con.ConnectionString = "Data Source=DESKTOP-3MAL78A\SQLEXPRESS01;Initial Catalog=LIS;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        display_data()

    End Sub

    'DISPLAYS DATABASE' 
    Public Sub display_data()

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * FROM MEMBERINFO "
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    'UPDATE BUTTON'
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        Me.Hide()
        Dim frm As New UPDATEMEMBER
        frm.Show()

    End Sub

    'DELETE BUTTON'
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Me.Hide()
        Dim frm As New DELETEMEMBER
        frm.Show()

    End Sub

    'CANCEL BUTTON'
    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click

        Me.Hide()
        Dim frm As New LIBRARYINFORMATION
        frm.Show()

    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click

    End Sub
End Class