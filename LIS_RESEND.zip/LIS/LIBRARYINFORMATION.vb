﻿Imports System.Windows.Forms

Public Class LIBRARYINFORMATION

   

    'YES BUTTON'
    Private Sub RadioButton1_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton1.CheckedChanged

        Me.Hide()
        Dim f As New MEMBERINFORMATION
        f.Show()

    End Sub

    'NO BUTTON'
    Private Sub RadioButton2_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton2.CheckedChanged

        Dim f As New NEWMEMBER
        f.Show()

    End Sub

    'MEMBERS INFORMATION MENU'
    Private Sub MEMBERSINFORMATIONToolStripMenuItem1_Click(sender As System.Object, e As System.EventArgs) Handles MEMBERSINFORMATIONToolStripMenuItem1.Click

        Me.Hide()
        Dim frm As New MEMBERINFORMATION
        frm.Show()

    End Sub

    'BORROW BOOKS MENU'
    Private Sub BORROWBOOKSToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles BORROWBOOKSToolStripMenuItem.Click

        Me.Hide()
        Dim frm As New BORROWBOOKS
        frm.Show()

    End Sub

    'RETURN BOOKS MENU'
    Private Sub RETURNBOOKSToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles RETURNBOOKSToolStripMenuItem.Click

        Me.Hide()
        Dim frm As New RETURNBOOKS
        frm.Show()

    End Sub

    'YAOI_YURI_REPRT REPORT'
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim frm As New YAOI_YURI_LIBRARY_REPORT
        frm.Show()
    End Sub

End Class