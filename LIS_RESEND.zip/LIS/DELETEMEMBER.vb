﻿Imports System.Data.Sql
Imports System.Data.SqlClient


Public Class DELETEMEMBER

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Dim NO_OF_BOOKS_NOT_RETURNED As Integer

    'DELETE FORM LOAD'
    Private Sub DELETEMEMBER_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LISDataSet.MEMBERINFO' table. You can move, or remove it, as needed.
        Me.MEMBERINFOTableAdapter.Fill(Me.LISDataSet.MEMBERINFO)
        con.ConnectionString = "Data Source=DESKTOP-3MAL78A\SQLEXPRESS01;Initial Catalog=LIS;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
    End Sub

    'DISPLAYS DATABASE' 
    Public Sub display_data()

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * FROM MEMBERINFO"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt


    End Sub

    'DELETE BUTTON'
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        'COUNTING NO_OF_BOOKS_NOT_RETURNED'
        Dim dateTime As String = "31-12-9998"
        Dim D As DateTime = Convert.ToDateTime(dateTime)
        Dim format As String = "yyyy-MM-dd"
        Dim str As String = D.ToString(format)
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT count([DATEOFRETURN) FROM RETURNSTATUS WHERE DATEOFRETURN ='" & str & "' AND MEMBERID ='" + TextBox1.Text + "'"
        NO_OF_BOOKS_NOT_RETURNED = CType(cmd.ExecuteScalar(), Integer)
        If NO_OF_BOOKS_NOT_RETURNED > 0 Then
            MessageBox.Show("YOU HAVE NOT RETURNED ALL BOOKS YOU HAVE BORROWED")
            Me.Hide()
            Dim frm As New RETURNBOOKS
            frm.Show()

        Else

            'DELETE MEMBER'
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "delete from MEMBERINFO where MEMBERID =" + TextBox1.Text + ""
            cmd.ExecuteNonQuery()
            MessageBox.Show("MEMBER RECORD HAS BEEN DELETED")
            display_data()

        End If


    End Sub

    'CANCEL BUTTON'
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Me.Hide()
        Dim frm As New LIBRARYINFORMATION
        frm.Show()

    End Sub


End Class