﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class BORROWBOOKS

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Dim NO_OF_BOOKS_NOT_RETURNED As Integer
    Dim i As Integer

    'BORROW BOOKS FORM LOAD'
    Private Sub BORROWBOOKS_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        con.ConnectionString = "Data Source=DESKTOP-3MAL78A\SQLEXPRESS01;Initial Catalog=LIS;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        display_data()
        Button1.Enabled = False
        Button3.Enabled = False

    End Sub

    'DISPLAYS DATABASE' 
    Public Sub display_data()

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM BOOKINFO"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    'DISPLAY RETURNSTATUS'
    Public Sub display_returnstatus()

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT R.MEMBERID , B.BOOKID , B.BOOKNAME, B.AUTHOR, R.DATEOFBORROW FROM BOOKINFO B,RETURNSTATUS R WHERE R.MEMBERID ='" + TextBox1.Text + "' AND B.BOOKID =R.BOOKID"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    'TEXTBOX1 ID SEARCH'
    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox1.TextChanged

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT MEMBERID FROM MEMBERINFO WHERE MEMBERID ='" + TextBox1.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        Dim M_ID As New Integer
        M_ID = CType(cmd.ExecuteScalar(), Integer)

        If M_ID = TextBox1.Text Then

            'COUNTING NO_OF_BOOKS_NOT_RETURNED'
            Dim dateTime As String = "31-12-9998"
            Dim D As DateTime = Convert.ToDateTime(dateTime)
            Dim format As String = "yyyy-MM-dd"
            Dim str As String = D.ToString(format)
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "SELECT count(DATEOFRETURN) FROM RETURNSTATUS WHERE DATEOFRETURN='" & str & "' AND MEMBERID ='" + TextBox1.Text + "'"
            NO_OF_BOOKS_NOT_RETURNED = CType(cmd.ExecuteScalar(), Integer)
            CALCULATE_NO_OF_BOOKS_TO_RETURN(NO_OF_BOOKS_NOT_RETURNED)
            i = NO_OF_BOOKS_NOT_RETURNED

        Else
            MessageBox.Show("NO SUCH ID FOUND")
        End If

    End Sub

    'CALCULATE NO OF BOOKS A MEMBER CAN BORROW'
    Public Sub CALCULATE_NO_OF_BOOKS_TO_RETURN(ByVal x As Integer)


        If (x = 0) Then

            MessageBox.Show("YOU CAN ONLY BORROW 3 BOOKS")

        ElseIf (x = 1) Then

            MessageBox.Show("YOU CAN ONLY BORROW 2 BOOKS, YOU MUST RETURN ONE BOOK")

        ElseIf (x = 2) Then

            MessageBox.Show("YOU CAN ONLY BORROW 1 BOOK, YOU MUST RETURN TWO BOOKS")

        ElseIf (x = 3) Then

            MessageBox.Show("YOU CANT BORROW ANY BOOKS , YOU MUST RETURN THREE BOOKS")
            Label6.Enabled = False
            Label3.Enabled = False
            Label4.Enabled = False
            Label5.Enabled = False
            TextBox2.Enabled = False
            TextBox3.Enabled = False
            TextBox4.Enabled = False
            DateTimePicker1.Enabled = False

        End If
    End Sub

    'BOOK ID ENTERING'
    Private Sub TextBox2_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox2.TextChanged


        Button1.Enabled = True
        Button3.Enabled = True
        Label1.Enabled = False
        TextBox1.Enabled = False
        DateTimePicker1.Enabled = False

    End Sub

    Private Sub DataGridView1_CellClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        'the try catch statement is used to handle any exception if formed.
        'using the index we select a particular row in the grid view data to undergo insert,update,del,search operation.
        Try
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
            con.Open()
            Dim i As Integer
            i = e.RowIndex
            Dim selectedrow As DataGridViewRow
            selectedrow = DataGridView1.Rows(i)
            TextBox2.Text = selectedrow.Cells(0).Value.ToString()
            TextBox3.Text = selectedrow.Cells(1).Value.ToString()
            TextBox4.Text = selectedrow.Cells(2).Value.ToString()

        Catch ex As Exception

        End Try
    End Sub

    'SEARCH BUTTON'
    Private Sub Button4_Click_1(sender As System.Object, e As System.EventArgs) Handles Button4.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * FROM BOOKINFO where BOOKID =" + TextBox2.Text + ""
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        If dt.Rows.Count() > 0 Then

            TextBox3.Text = dt.Rows(0)(1).ToString()
            TextBox4.Text = dt.Rows(0)(2).ToString()

        Else

            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            MessageBox.Show("NO SUCH BOOK FOUND")

        End If
    End Sub

    'ADD BUTTON'
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        Dim dateTime As String = "31-12-9998"
        Dim dt As DateTime = Convert.ToDateTime(dateTime)
        Dim format As String = "yyyy-MM-dd"
        Dim str As String = dt.ToString(format)
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text

        If (i = 0) Then
            cmd.CommandText = "INSERT INTO RETURNSTATUS VALUES ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & DateTimePicker1.Text & "','" & str & "')"
            cmd.ExecuteNonQuery()
            i = i + 1
            MessageBox.Show("BOOK ADDED SUCCESFULLY")
            display_data()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()

        ElseIf (i = 1) Then
            cmd.CommandText = "INSERT INTO RETURNSTATUS VALUES ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & DateTimePicker1.Text & "','" & str & "')"
            cmd.ExecuteNonQuery()
            i = i + 1
            MessageBox.Show("BOOK ADDED SUCCESFULLY")
            display_data()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()

        ElseIf (i = 2) Then
            cmd.CommandText = "INSERT INTO RETURNSTATUS VALUES ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & DateTimePicker1.Text & "','" & str & "')"
            cmd.ExecuteNonQuery()
            i = i + 1
            MessageBox.Show("BOOK ADDED SUCCESFULLY")
            display_data()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()

        ElseIf (i = 3) Then

            MessageBox.Show("BORROW LIMIT IS THREE")
            Label3.Enabled = False
            Label4.Enabled = False
            TextBox2.Enabled = False
            TextBox3.Enabled = False
            TextBox4.Enabled = False
            Button1.Enabled = False
            Button3.Enabled = False

        End If

    End Sub

    'SAVE BUTTON'
    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click

        display_returnstatus()

    End Sub

    'CANCEL BUTTON'
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Me.Hide()
        Dim frm As New LIBRARYINFORMATION
        frm.Show()

    End Sub

End Class