﻿Public Class MEMBER_REPORT

    'MEMBER REPOERT LOAD'
    Private Sub MEMBER_REPORT_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LISDataSet3.RETURNSTATUS' table. You can move, or remove it, as needed.
        Me.RETURNSTATUSTableAdapter.Fill(Me.LISDataSet3.RETURNSTATUS)

    End Sub

    'MEMBER REPORT GENERATE BUTTON'
    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click


    End Sub
End Class