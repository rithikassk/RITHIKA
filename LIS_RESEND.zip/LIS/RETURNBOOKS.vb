﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class RETURNBOOKS

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    'RETURN BOOKS FORM LOAD'
    Private Sub RETURNBOOKS_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        con.ConnectionString = "Data Source=DESKTOP-3MAL78A\SQLEXPRESS01;Initial Catalog=LIS;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()

    End Sub

    'MEMBER ID TEXTBOX'
    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox1.TextChanged

        'CONVERTING STRING TO DATE'
        Dim dateTime As String = "31-12-9998"
        Dim D As DateTime = Convert.ToDateTime(dateTime)
        Dim format As String = "yyyy-MM-dd"
        Dim str As String = D.ToString(format)

        'UPDATE QUERY'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT B.BOOKID, B.BOOKNAME FROM BOOKINFO B, RETURNSTATUS R , MEMBERINFO M WHERE R.MEMBERID = M.MEMBERID  AND R.DATEOFRETURN ='" & str & "' AND B.BOOKID= R.BOOKID AND R.MEMBERID='" + TextBox1.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        If dt.Rows.Count() = 1 Then

            TextBox5.Text = dt.Rows(0)(0).ToString()
            TextBox2.Text = dt.Rows(0)(1).ToString()

        ElseIf dt.Rows.Count() = 2 Then

            TextBox5.Text = dt.Rows(0)(0).ToString()
            TextBox2.Text = dt.Rows(0)(1).ToString()
            TextBox6.Text = dt.Rows(1)(0).ToString()
            TextBox3.Text = dt.Rows(1)(1).ToString()

        ElseIf dt.Rows.Count() = 3 Then

            TextBox5.Text = dt.Rows(0)(0).ToString()
            TextBox2.Text = dt.Rows(0)(1).ToString()
            TextBox6.Text = dt.Rows(1)(0).ToString()
            TextBox3.Text = dt.Rows(1)(1).ToString()
            TextBox7.Text = dt.Rows(2)(0).ToString()
            TextBox4.Text = dt.Rows(2)(1).ToString()

        Else

            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            MessageBox.Show("NO SUCH ID FOUND")

        End If

    End Sub

    'CHECKBOX 1'
    Private Sub CheckBox1_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox1.CheckedChanged

        'CONVERTING STRING TO DATE'
        Dim dateTime As String = "31-12-9998"
        Dim D As DateTime = Convert.ToDateTime(dateTime)
        Dim format As String = "yyyy-MM-dd"
        Dim str As String = D.ToString(format)

        'UPDATE [DATE OF RETURN]'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE RETURNSTATUS SET DATEOFRETURN='" + DateTimePicker1.Value.ToString(format) + "'WHERE MEMBERID ='" + TextBox1.Text + "' AND BOOKID ='" + TextBox5.Text + "' AND DATEOFRETURN ='" & str & "'"
        cmd.ExecuteNonQuery()

        'FIND DATE DIFFERENCE'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT DATEOFBORROW FROM RETURNSTATUS WHERE MEMBERID ='" + TextBox1.Text + "'AND BOOKID ='" + TextBox5.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        Dim book1 As DateTime
        book1 = dt.Rows(0)(0)
        ' MsgBox(book1)
        Dim datediff As TimeSpan
        datediff = Now.Date.Subtract(book1)
        If (datediff.Days > 7) Then
            CheckBox1.Text = "FINE APPLIED"
        Else
            CheckBox1.Text = "NO FINE "
        End If

    End Sub

    'CHECKBOX 2'
    Private Sub CheckBox2_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox2.CheckedChanged

        'CONvERTING STRING TO DATE'
        Dim dateTime As String = "31-12-9998"
        Dim D As DateTime = Convert.ToDateTime(dateTime)
        Dim format As String = "yyyy-MM-dd"
        Dim str As String = D.ToString(format)

        'UPDATE [DATE OF RETURN]'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE RETURNSTATUS SET DATEOFRETURN ='" + DateTimePicker1.Value.ToString(format) + "'WHERE MEMBERID ='" + TextBox1.Text + "' AND BOOKID ='" + TextBox6.Text + "' AND DATEOFRETURN ='" & str & "'"
        cmd.ExecuteNonQuery()

        'FIND DATE DIFFERENCE'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT DATEOFBORROW FROM RETURNSTATUS WHERE MEMBERID ='" + TextBox1.Text + "'AND BOOKID ='" + TextBox6.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        Dim book1 As DateTime
        book1 = dt.Rows(0)(0)
        Dim datediff As TimeSpan
        datediff = Now.Date.Subtract(book1)
        If (datediff.Days > 7) Then
            CheckBox2.Text = "FINE APPLIED"
        Else
            CheckBox2.Text = "NO FINE "
        End If

    End Sub

    'CHECKBOX 3'
    Private Sub CheckBox3_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox3.CheckedChanged

        'CONVERTING STRING TO DATE'
        Dim dateTime As String = "31-12-9998"
        Dim D As DateTime = Convert.ToDateTime(dateTime)
        Dim format As String = "yyyy-MM-dd"
        Dim str As String = D.ToString(format)

        'UPDATE [DATE OF RETURN]'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE RETURNSTATUS SET DATEOFRETURN ='" + DateTimePicker1.Value.ToString(format) + "'WHERE MEMBERID ='" + TextBox1.Text + "' AND BOOKID ='" + TextBox7.Text + "' AND DATEOFRETURN ='" & str & "'"
        cmd.ExecuteNonQuery()

        'FIND DATE DIFFERENCE'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT DATEOFBORROW FROM RETURNSTATUS WHERE MEMBERID ='" + TextBox1.Text + "'AND BOOKID ='" + TextBox7.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        Dim book1 As DateTime
        book1 = dt.Rows(0)(0)
        Dim datediff As TimeSpan
        datediff = Now.Date.Subtract(book1)
        If (datediff.Days > 7) Then
            CheckBox3.Text = "FINE APPLIED"
        Else
            CheckBox3.Text = "NO FINE "
        End If

    End Sub

    'SAVE BUTTON'
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        MessageBox.Show("SAVED!")
        Me.Hide()
        Dim frm As New LIBRARYINFORMATION
        frm.Show()


    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Me.Hide()
        Dim frm As New LIBRARYINFORMATION
        frm.Show()

    End Sub

End Class