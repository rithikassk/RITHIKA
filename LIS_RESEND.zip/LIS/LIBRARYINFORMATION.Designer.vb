﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LIBRARYINFORMATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LIBRARYINFORMATION))
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.MEMBERSINFORMATIONToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BORROWBOOKSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RETURNBOOKSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(476, 90)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(366, 332)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 21
        Me.PictureBox2.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Perpetua Titling MT", 13.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(16, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(353, 27)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "DO YOU HAVE MEMBERSHIP?"
        '
        'MenuStrip
        '
        Me.MenuStrip.AutoSize = False
        Me.MenuStrip.BackColor = System.Drawing.Color.Indigo
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MEMBERSINFORMATIONToolStripMenuItem1, Me.BORROWBOOKSToolStripMenuItem, Me.RETURNBOOKSToolStripMenuItem})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Padding = New System.Windows.Forms.Padding(9, 3, 0, 3)
        Me.MenuStrip.Size = New System.Drawing.Size(923, 60)
        Me.MenuStrip.TabIndex = 18
        Me.MenuStrip.Text = "MenuStrip"
        '
        'MEMBERSINFORMATIONToolStripMenuItem1
        '
        Me.MEMBERSINFORMATIONToolStripMenuItem1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.MEMBERSINFORMATIONToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MEMBERSINFORMATIONToolStripMenuItem1.Font = New System.Drawing.Font("Microsoft YaHei UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.MEMBERSINFORMATIONToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.MEMBERSINFORMATIONToolStripMenuItem1.Margin = New System.Windows.Forms.Padding(1)
        Me.MEMBERSINFORMATIONToolStripMenuItem1.Name = "MEMBERSINFORMATIONToolStripMenuItem1"
        Me.MEMBERSINFORMATIONToolStripMenuItem1.Size = New System.Drawing.Size(254, 52)
        Me.MEMBERSINFORMATIONToolStripMenuItem1.Text = "    MEMBER  INFORMATION       "
        '
        'BORROWBOOKSToolStripMenuItem
        '
        Me.BORROWBOOKSToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BORROWBOOKSToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.BORROWBOOKSToolStripMenuItem.Font = New System.Drawing.Font("Microsoft YaHei UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.BORROWBOOKSToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.BORROWBOOKSToolStripMenuItem.Margin = New System.Windows.Forms.Padding(1)
        Me.BORROWBOOKSToolStripMenuItem.Name = "BORROWBOOKSToolStripMenuItem"
        Me.BORROWBOOKSToolStripMenuItem.Size = New System.Drawing.Size(248, 52)
        Me.BORROWBOOKSToolStripMenuItem.Text = "           BORROW BOOKS              "
        '
        'RETURNBOOKSToolStripMenuItem
        '
        Me.RETURNBOOKSToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlDark
        Me.RETURNBOOKSToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RETURNBOOKSToolStripMenuItem.Font = New System.Drawing.Font("Microsoft YaHei UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.RETURNBOOKSToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RETURNBOOKSToolStripMenuItem.Margin = New System.Windows.Forms.Padding(1)
        Me.RETURNBOOKSToolStripMenuItem.Name = "RETURNBOOKSToolStripMenuItem"
        Me.RETURNBOOKSToolStripMenuItem.Size = New System.Drawing.Size(249, 52)
        Me.RETURNBOOKSToolStripMenuItem.Text = "            RETURN BOOKS               "
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.DarkOrchid
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft YaHei UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(38, 90)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(396, 255)
        Me.GroupBox1.TabIndex = 19
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "MEMBERSHIP"
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton1.Font = New System.Drawing.Font("Perpetua Titling MT", 13.0!, System.Drawing.FontStyle.Bold)
        Me.RadioButton1.ForeColor = System.Drawing.Color.White
        Me.RadioButton1.Location = New System.Drawing.Point(97, 138)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(75, 31)
        Me.RadioButton1.TabIndex = 10
        Me.RadioButton1.Text = "YES"
        Me.RadioButton1.UseVisualStyleBackColor = False
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton2.Font = New System.Drawing.Font("Perpetua Titling MT", 13.0!, System.Drawing.FontStyle.Bold)
        Me.RadioButton2.ForeColor = System.Drawing.Color.White
        Me.RadioButton2.Location = New System.Drawing.Point(218, 138)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(70, 31)
        Me.RadioButton2.TabIndex = 11
        Me.RadioButton2.Text = "NO"
        Me.RadioButton2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Indigo
        Me.Button1.Font = New System.Drawing.Font("Microsoft YaHei", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Button1.Location = New System.Drawing.Point(38, 386)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(396, 36)
        Me.Button1.TabIndex = 22
        Me.Button1.Text = "YAOI YURI LIBRARY REPORT"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'LIBRARYINFORMATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Thistle
        Me.ClientSize = New System.Drawing.Size(923, 507)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.MenuStrip)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "LIBRARYINFORMATION"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "YAOI YURI COMICZZ LIBRARY"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents MEMBERSINFORMATIONToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BORROWBOOKSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RETURNBOOKSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
