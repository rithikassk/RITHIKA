﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DELETEMEMBER
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.MEMBERINFOBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LISDataSet = New LIS.LISDataSet()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MEMBERINFOTableAdapter = New LIS.LISDataSetTableAdapters.MEMBERINFOTableAdapter()
        Me.MEMBERID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MEMBERNAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PHONENUMBER = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PLACEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MEMBERINFOBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LISDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.MEMBERID, Me.MEMBERNAME, Me.PHONENUMBER, Me.PLACEDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.MEMBERINFOBindingSource
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.Location = New System.Drawing.Point(11, 84)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(900, 411)
        Me.DataGridView1.TabIndex = 10
        '
        'MEMBERINFOBindingSource
        '
        Me.MEMBERINFOBindingSource.DataMember = "MEMBERINFO"
        Me.MEMBERINFOBindingSource.DataSource = Me.LISDataSet
        '
        'LISDataSet
        '
        Me.LISDataSet.DataSetName = "LISDataSet"
        Me.LISDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.MediumPurple
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(706, 22)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(152, 49)
        Me.Button2.TabIndex = 9
        Me.Button2.Text = "CANCEL"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.MediumPurple
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(500, 22)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(152, 49)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "DELETE"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(243, 36)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(180, 22)
        Me.TextBox1.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(87, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 20)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "MEMBER ID"
        '
        'MEMBERINFOTableAdapter
        '
        Me.MEMBERINFOTableAdapter.ClearBeforeFill = True
        '
        'MEMBERID
        '
        Me.MEMBERID.DataPropertyName = "MEMBERID"
        Me.MEMBERID.HeaderText = "MEMBER ID"
        Me.MEMBERID.Name = "MEMBERID"
        Me.MEMBERID.Width = 110
        '
        'MEMBERNAME
        '
        Me.MEMBERNAME.DataPropertyName = "MEMBERNAME"
        Me.MEMBERNAME.HeaderText = "MEMBER NAME"
        Me.MEMBERNAME.Name = "MEMBERNAME"
        Me.MEMBERNAME.Width = 200
        '
        'PHONENUMBER
        '
        Me.PHONENUMBER.DataPropertyName = "PHONENUMBER"
        Me.PHONENUMBER.HeaderText = "PHONE NUMBER"
        Me.PHONENUMBER.Name = "PHONENUMBER"
        Me.PHONENUMBER.Width = 150
        '
        'PLACEDataGridViewTextBoxColumn
        '
        Me.PLACEDataGridViewTextBoxColumn.DataPropertyName = "PLACE"
        Me.PLACEDataGridViewTextBoxColumn.HeaderText = "PLACE"
        Me.PLACEDataGridViewTextBoxColumn.Name = "PLACEDataGridViewTextBoxColumn"
        Me.PLACEDataGridViewTextBoxColumn.Width = 180
        '
        'DELETEMEMBER
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Thistle
        Me.ClientSize = New System.Drawing.Size(923, 507)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "DELETEMEMBER"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DELETE MEMBER"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MEMBERINFOBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LISDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LISDataSet As LIS.LISDataSet
    Friend WithEvents MEMBERINFOBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MEMBERINFOTableAdapter As LIS.LISDataSetTableAdapters.MEMBERINFOTableAdapter
    Friend WithEvents MEMBERIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MEMBERNAMEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PHONENUMBERDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MEMBERID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MEMBERNAME As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PHONENUMBER As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PLACEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
