﻿Imports System.Data.Sql
Imports System.Data.SqlClient


Public Class NEWMEMBER

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    'NEWMEMBER LOAD'
    Private Sub NEWMEMBER_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LISDataSet.MEMBERINFO' table. You can move, or remove it, as needed.
        Me.MEMBERINFOTableAdapter.Fill(Me.LISDataSet.MEMBERINFO)
        con.ConnectionString = "Data Source=DESKTOP-3MAL78A\SQLEXPRESS01;Initial Catalog=LIS;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        id()

    End Sub


    'DISPLAYS DATABASE' 
    Public Sub display_data()

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM MEMBERINFO WHERE MEMBERID =" + TextBox1.Text + ""
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    'ID NEW GENERATE'
    Public Sub id()

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        Dim id As Integer
        cmd.CommandText = "SELECT MEMBERID FROM MEMBERINFO ORDER BY MEMBERID DESC "
        id = CType(cmd.ExecuteScalar(), Integer)
        MessageBox.Show("YOUR NEW MEMBER ID IS : " & id + 1)
        TextBox1.Text = id + 1

    End Sub

    'ADD BUTTON'
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "INSERT INTO MEMBERINFO VALUES('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + ComboBox1.SelectedItem + "')"
        cmd.ExecuteNonQuery()
        MessageBox.Show("MEMBER NEWLY ADDED!")
        display_data()

    End Sub

    'CANCEL BUTTON'
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Me.Hide()
        Dim frm As New LIBRARYINFORMATION
        frm.Show()

    End Sub

End Class