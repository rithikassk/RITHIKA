﻿Imports System.Data.Sql
Imports System.Data.SqlClient


Public Class Form4

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    'BANK FORM LOAD'
    Private Sub Form4_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        con.ConnectionString = ""
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()

        Tid()

        'DISABLING PAY BUTTON'
        Button2.Enabled = False

    End Sub

    'GENERATING TRANSACTION ID'
    Public Sub Tid()

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        Dim id As Integer
        cmd.CommandText = "SELECT TID FROM TRANS ORDER BY TID DESC  "
        id = CType(cmd.ExecuteScalar(), Integer)
        TRANSIDTXT.Text = id + 1
        ACCNUMTXT.Focus()

    End Sub

    'SEARCHING YOUR ACCOUNT DETAILS AND DISPLAYING IN DATAGRIDEVIEW 1'
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM ACCOUNTINFO WHERE='" & ACCNUMTXT.Text & "'  "
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    'CHECKING IF YOUR ACC NUM VALID OR NOT'
    Private Sub ACCNUMTXT_Leave(sender As System.Object, e As System.EventArgs) Handles ACCNUMTXT.Leave

        Dim C As Integer
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT count(ACCNUM) FROM ACCOUNTINFO WHERE ACCNUM = " & ACCNUMTXT.Text & ""
        C = CType(cmd.ExecuteScalar(), Integer)

        If C = 0 Then

            MessageBox.Show("INVALID ACCOUNT NUMBER")

            ACCNUMTXT.Clear()
            ACCNUMTXT.Focus()

        Else

            TextBox3.Focus()

        End If

    End Sub

    'CHECKING IF YOUR ACC NUM VALID OR NOT'
    Private Sub TextBox3_Leave(sender As System.Object, e As System.EventArgs) Handles TextBox3.Leave

        Dim C As Integer
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT count(ACCNUM) FROM ACCOUNTINFO WHERE ACCNUM = " & ACCNUMTXT.Text & ""
        C = CType(cmd.ExecuteScalar(), Integer)

        If C = 0 Then

            MessageBox.Show("INVALID ACCOUNT NUMBER")

            ACCNUMTXT.Clear()
            ACCNUMTXT.Focus()

        Else

            AMOUNTTXT.Focus()

        End If

    End Sub

    'TRANSFER AMOUNT'
    Private Sub AMOUNTTXT_Leave(sender As Object, e As System.EventArgs) Handles AMOUNTTXT.Leave

        'ENABLING PAY BUTTON'
        Button2.Enabled = False

        Dim TAMOUNT As Decimal = 0
        TAMOUNT = TAMOUNT + AMOUNTTXT.Text

        If TAMOUNT < 50 Then


            MessageBox.Show("TRANSFER AMOUNT IS TOO LOW FOR TRANSACTION.")
            AMOUNTTXT.Clear()
            AMOUNTTXT.Focus()

        ElseIf TAMOUNT > 10000 Then


            MessageBox.Show("TRANSACTION AMOUNT LIMIT IS BEING EXCEEDED.")
            AMOUNTTXT.Clear()
            AMOUNTTXT.Focus()

        End If

    End Sub

    'PAY BUTTON'
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Dim CBAL As Decimal
        Dim DBAL As Decimal

        'GETTING CREDITOR BALANCE'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT  BALANCE FROM ACCOUNTINFO WHERE ACCNUM = " & ACCNUMTXT.Text & ""
        CBAL = CType(cmd.ExecuteScalar(), Decimal)

        'GETTING DEBITOR BALANCE'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT  BALANCE FROM ACCOUNTINFO WHERE ACCNUM = '" + TextBox3.Text + "'"
        DBAL = CType(cmd.ExecuteScalar(), Decimal)

        'UPDATING CREDITORS BALANCE'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "INSERT INTO TRANS VALUES('" & TRANSIDTXT.Text & "','" & ACCNUMTXT.Text & "','" & TextBox3.Text & "','" & (-1 * AMOUNTTXT.Text) & "')"
        cmd.ExecuteNonQuery()

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE ACCOUNT SET BALANCE =" & (CBAL - AMOUNTTXT.Text) & "WHERE ACCNUM=" & ACCNUMTXT.Text & ""
        cmd.ExecuteNonQuery()

        'UPDATING DEBITORS BALANCE'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "INSERT INTO TRANS VALUES('" & TRANSIDTXT.Text & "','" & ACCNUMTXT.Text & "','" & TextBox3.Text & "','" & AMOUNTTXT.Text & "')"
        cmd.ExecuteNonQuery()

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE ACCOUNT SET BALANCE =" & (DBAL + AMOUNTTXT.Text) & "WHERE ACCNUM=" & ACCNUMTXT.Text & ""
        cmd.ExecuteNonQuery()

        DGV2()
        MessageBox.Show(" TRANSACTION SUCCESSFUL")

    End Sub

    'TO DISPLAY TRANSACTION DETAILS'
    Public Sub DGV2()
      
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM TRANS WHERE='" & ACCNUMTXT.Text & "' "
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        DataGridView2.DataSource = dt


    End Sub

    'CANCEL BUTTON'
    Private Sub Cancel_Click(sender As System.Object, e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

End Class