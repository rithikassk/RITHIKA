﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.OSTXT = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NAMETXT = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.REGNUMTXT = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.CATXT = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.VBTXT = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.DBMSTXT = New System.Windows.Forms.TextBox()
        Me.OSGRADETXT = New System.Windows.Forms.TextBox()
        Me.VBGRADETXT = New System.Windows.Forms.TextBox()
        Me.CAGRADETXT = New System.Windows.Forms.TextBox()
        Me.DBMSGRADETXT = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TOTALTXT = New System.Windows.Forms.TextBox()
        Me.OSRESULTTXT = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.VBRESULTTXT = New System.Windows.Forms.TextBox()
        Me.CARESULTTXT = New System.Windows.Forms.TextBox()
        Me.DBMSRESULTTXT = New System.Windows.Forms.TextBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.RESULTTXT = New System.Windows.Forms.TextBox()
        Me.GRADETXT = New System.Windows.Forms.TextBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(918, 96)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(518, 522)
        Me.DataGridView1.TabIndex = 30
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.Button5.Location = New System.Drawing.Point(1194, 638)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(171, 57)
        Me.Button5.TabIndex = 29
        Me.Button5.Text = "CLOSE"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.Button4.Location = New System.Drawing.Point(487, 84)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(159, 46)
        Me.Button4.TabIndex = 28
        Me.Button4.Text = "SEARCH"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.Button3.Location = New System.Drawing.Point(400, 676)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(171, 57)
        Me.Button3.TabIndex = 27
        Me.Button3.Text = "UPDATE"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.Button2.Location = New System.Drawing.Point(1000, 638)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(171, 57)
        Me.Button2.TabIndex = 26
        Me.Button2.Text = "CLEAR"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'OSTXT
        '
        Me.OSTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OSTXT.Location = New System.Drawing.Point(262, 275)
        Me.OSTXT.Name = "OSTXT"
        Me.OSTXT.Size = New System.Drawing.Size(136, 30)
        Me.OSTXT.TabIndex = 25
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(81, 281)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 24)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "OS"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(82, 358)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 24)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "VB"
        '
        'NAMETXT
        '
        Me.NAMETXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NAMETXT.Location = New System.Drawing.Point(230, 148)
        Me.NAMETXT.Name = "NAMETXT"
        Me.NAMETXT.ReadOnly = True
        Me.NAMETXT.Size = New System.Drawing.Size(217, 30)
        Me.NAMETXT.TabIndex = 21
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(35, 153)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 24)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = " NAME"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(679, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(364, 36)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "SEMESTER 4 MARKLIST"
        '
        'REGNUMTXT
        '
        Me.REGNUMTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.REGNUMTXT.Location = New System.Drawing.Point(230, 90)
        Me.REGNUMTXT.Name = "REGNUMTXT"
        Me.REGNUMTXT.Size = New System.Drawing.Size(217, 30)
        Me.REGNUMTXT.TabIndex = 18
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(34, 96)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(190, 24)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "REGISTER NUMBER"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.Button1.Location = New System.Drawing.Point(202, 676)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(171, 57)
        Me.Button1.TabIndex = 16
        Me.Button1.Text = "INSERT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CATXT
        '
        Me.CATXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CATXT.Location = New System.Drawing.Point(262, 424)
        Me.CATXT.Name = "CATXT"
        Me.CATXT.Size = New System.Drawing.Size(136, 30)
        Me.CATXT.TabIndex = 32
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(68, 499)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 24)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "DBMS"
        '
        'VBTXT
        '
        Me.VBTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VBTXT.Location = New System.Drawing.Point(262, 353)
        Me.VBTXT.Name = "VBTXT"
        Me.VBTXT.Size = New System.Drawing.Size(136, 30)
        Me.VBTXT.TabIndex = 34
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(81, 430)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(36, 24)
        Me.Label7.TabIndex = 33
        Me.Label7.Text = "CA"
        '
        'DBMSTXT
        '
        Me.DBMSTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DBMSTXT.Location = New System.Drawing.Point(262, 493)
        Me.DBMSTXT.Name = "DBMSTXT"
        Me.DBMSTXT.Size = New System.Drawing.Size(136, 30)
        Me.DBMSTXT.TabIndex = 35
        '
        'OSGRADETXT
        '
        Me.OSGRADETXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OSGRADETXT.Location = New System.Drawing.Point(487, 275)
        Me.OSGRADETXT.Name = "OSGRADETXT"
        Me.OSGRADETXT.ReadOnly = True
        Me.OSGRADETXT.Size = New System.Drawing.Size(136, 30)
        Me.OSGRADETXT.TabIndex = 39
        '
        'VBGRADETXT
        '
        Me.VBGRADETXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VBGRADETXT.Location = New System.Drawing.Point(487, 353)
        Me.VBGRADETXT.Name = "VBGRADETXT"
        Me.VBGRADETXT.ReadOnly = True
        Me.VBGRADETXT.Size = New System.Drawing.Size(136, 30)
        Me.VBGRADETXT.TabIndex = 38
        '
        'CAGRADETXT
        '
        Me.CAGRADETXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CAGRADETXT.Location = New System.Drawing.Point(487, 430)
        Me.CAGRADETXT.Name = "CAGRADETXT"
        Me.CAGRADETXT.ReadOnly = True
        Me.CAGRADETXT.Size = New System.Drawing.Size(136, 30)
        Me.CAGRADETXT.TabIndex = 37
        '
        'DBMSGRADETXT
        '
        Me.DBMSGRADETXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DBMSGRADETXT.Location = New System.Drawing.Point(487, 499)
        Me.DBMSGRADETXT.Name = "DBMSGRADETXT"
        Me.DBMSGRADETXT.ReadOnly = True
        Me.DBMSGRADETXT.Size = New System.Drawing.Size(136, 30)
        Me.DBMSGRADETXT.TabIndex = 36
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(35, 225)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(146, 24)
        Me.Label8.TabIndex = 40
        Me.Label8.Text = "SUBECT NAME"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(287, 225)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(76, 24)
        Me.Label9.TabIndex = 41
        Me.Label9.Text = "MARKS"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(518, 225)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(76, 24)
        Me.Label10.TabIndex = 42
        Me.Label10.Text = "GRADE"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(59, 576)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 24)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "TOTAL"
        '
        'TOTALTXT
        '
        Me.TOTALTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TOTALTXT.Location = New System.Drawing.Point(262, 570)
        Me.TOTALTXT.Name = "TOTALTXT"
        Me.TOTALTXT.Size = New System.Drawing.Size(136, 30)
        Me.TOTALTXT.TabIndex = 44
        '
        'OSRESULTTXT
        '
        Me.OSRESULTTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OSRESULTTXT.Location = New System.Drawing.Point(713, 276)
        Me.OSRESULTTXT.Name = "OSRESULTTXT"
        Me.OSRESULTTXT.ReadOnly = True
        Me.OSRESULTTXT.Size = New System.Drawing.Size(136, 30)
        Me.OSRESULTTXT.TabIndex = 51
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(744, 225)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(83, 24)
        Me.Label12.TabIndex = 50
        Me.Label12.Text = "RESULT"
        '
        'VBRESULTTXT
        '
        Me.VBRESULTTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VBRESULTTXT.Location = New System.Drawing.Point(713, 352)
        Me.VBRESULTTXT.Name = "VBRESULTTXT"
        Me.VBRESULTTXT.ReadOnly = True
        Me.VBRESULTTXT.Size = New System.Drawing.Size(136, 30)
        Me.VBRESULTTXT.TabIndex = 49
        '
        'CARESULTTXT
        '
        Me.CARESULTTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CARESULTTXT.Location = New System.Drawing.Point(713, 430)
        Me.CARESULTTXT.Name = "CARESULTTXT"
        Me.CARESULTTXT.ReadOnly = True
        Me.CARESULTTXT.Size = New System.Drawing.Size(136, 30)
        Me.CARESULTTXT.TabIndex = 48
        '
        'DBMSRESULTTXT
        '
        Me.DBMSRESULTTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DBMSRESULTTXT.Location = New System.Drawing.Point(713, 499)
        Me.DBMSRESULTTXT.Name = "DBMSRESULTTXT"
        Me.DBMSRESULTTXT.ReadOnly = True
        Me.DBMSRESULTTXT.Size = New System.Drawing.Size(136, 30)
        Me.DBMSRESULTTXT.TabIndex = 47
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.Button6.Location = New System.Drawing.Point(593, 676)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(171, 57)
        Me.Button6.TabIndex = 52
        Me.Button6.Text = "DELETE"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'RESULTTXT
        '
        Me.RESULTTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RESULTTXT.Location = New System.Drawing.Point(713, 570)
        Me.RESULTTXT.Name = "RESULTTXT"
        Me.RESULTTXT.ReadOnly = True
        Me.RESULTTXT.Size = New System.Drawing.Size(136, 30)
        Me.RESULTTXT.TabIndex = 46
        '
        'GRADETXT
        '
        Me.GRADETXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GRADETXT.Location = New System.Drawing.Point(487, 571)
        Me.GRADETXT.Name = "GRADETXT"
        Me.GRADETXT.ReadOnly = True
        Me.GRADETXT.Size = New System.Drawing.Size(136, 30)
        Me.GRADETXT.TabIndex = 45
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1588, 768)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.OSRESULTTXT)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.VBRESULTTXT)
        Me.Controls.Add(Me.CARESULTTXT)
        Me.Controls.Add(Me.DBMSRESULTTXT)
        Me.Controls.Add(Me.RESULTTXT)
        Me.Controls.Add(Me.GRADETXT)
        Me.Controls.Add(Me.TOTALTXT)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.OSGRADETXT)
        Me.Controls.Add(Me.VBGRADETXT)
        Me.Controls.Add(Me.CAGRADETXT)
        Me.Controls.Add(Me.DBMSGRADETXT)
        Me.Controls.Add(Me.DBMSTXT)
        Me.Controls.Add(Me.VBTXT)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.CATXT)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.OSTXT)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.NAMETXT)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.REGNUMTXT)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form3"
        Me.Text = "Form3"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents OSTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents NAMETXT As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents REGNUMTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents CATXT As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents VBTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents DBMSTXT As System.Windows.Forms.TextBox
    Friend WithEvents OSGRADETXT As System.Windows.Forms.TextBox
    Friend WithEvents VBGRADETXT As System.Windows.Forms.TextBox
    Friend WithEvents CAGRADETXT As System.Windows.Forms.TextBox
    Friend WithEvents DBMSGRADETXT As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TOTALTXT As System.Windows.Forms.TextBox
    Friend WithEvents OSRESULTTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents VBRESULTTXT As System.Windows.Forms.TextBox
    Friend WithEvents CARESULTTXT As System.Windows.Forms.TextBox
    Friend WithEvents DBMSRESULTTXT As System.Windows.Forms.TextBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents RESULTTXT As System.Windows.Forms.TextBox
    Friend WithEvents GRADETXT As System.Windows.Forms.TextBox
End Class
