﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class Form3

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub Form3_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        con.ConnectionString = ""
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()



    End Sub

    'SEARCH'
    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select STUDNAME,OS,VB,CA,DBMS FROM STUDINFO,MARKS where REGNUM ='" + REGNUMTXT.Text + "'"
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.SelectCommand = cmd
        da.Fill(dt)
        If dt.Rows.Count() > 0 Then

            NAMETXT.Text = dt.Rows(0)(0).ToString()
            OSTXT.Text = dt.Rows(0)(1).ToString()
            VBTXT.Text = dt.Rows(0)(2).ToString()
            CATXT.Text = dt.Rows(0)(3).ToString()
            DBMSTXT.Text = dt.Rows(0)(4).ToString()


        Else


        End If

    End Sub

    'OS MARK,GRADE,RESULT'
    Private Sub OSTXT_Leave(sender As System.Object, e As System.EventArgs) Handles OSTXT.Leave

        Dim a As Integer
        a = OSTXT.Text

        If a >= 80 And a <= 100 Then

            OSGRADETXT.Text = "A+"
            OSRESULTTXT.Text = "PASS"

        ElseIf (a >= 70 And a <= 79) Then

            OSGRADETXT.Text = "A"
            OSRESULTTXT.Text = "PASS"

        ElseIf (a >= 60 And a <= 69) Then

            OSGRADETXT.Text = "B"
            OSRESULTTXT.Text = "PASS"

        ElseIf a >= 50 And a <= 59 Then

            OSGRADETXT.Text = "C"
            OSRESULTTXT.Text = "PASS"

        ElseIf a >= 40 And a <= 49 Then

            OSGRADETXT.Text = "D"
            OSRESULTTXT.Text = "FAIL"

        End If

    End Sub

    'VB MARK,GRADE,RESULT'
    Private Sub VBTXT_Leave(sender As Object, e As System.EventArgs) Handles VBTXT.Leave

        Dim a As Integer
        a = VBTXT.Text

        If a >= 80 And a <= 100 Then

            VBGRADETXT.Text = "A+"
            VBRESULTTXT.Text = "PASS"

        ElseIf (a >= 70 And a <= 79) Then

            VBGRADETXT.Text = "A"
            VBRESULTTXT.Text = "PASS"

        ElseIf (a >= 60 And a <= 69) Then

            VBGRADETXT.Text = "B"
            VBRESULTTXT.Text = "PASS"

        ElseIf a >= 50 And a <= 59 Then

            VBGRADETXT.Text = "C"
            VBRESULTTXT.Text = "PASS"

        ElseIf a >= 40 And a <= 49 Then

            VBGRADETXT.Text = "D"
            VBRESULTTXT.Text = "FAIL"

        End If

    End Sub

    'CA MARK,GRADE,RESULT'
    Private Sub CATXT_Leave(sender As Object, e As System.EventArgs) Handles CATXT.Leave

        Dim a As Integer
        a = CATXT.Text

        If a >= 80 And a <= 100 Then

            CAGRADETXT.Text = "A+"
            CARESULTTXT.Text = "PASS"

        ElseIf (a >= 70 And a <= 79) Then

            CAGRADETXT.Text = "A"
            CARESULTTXT.Text = "PASS"

        ElseIf (a >= 60 And a <= 69) Then

            CAGRADETXT.Text = "B"
            CARESULTTXT.Text = "PASS"

        ElseIf a >= 50 And a <= 59 Then

            CAGRADETXT.Text = "C"
            CARESULTTXT.Text = "PASS"

        ElseIf a >= 40 And a <= 49 Then

            CAGRADETXT.Text = "D"
            CARESULTTXT.Text = "FAIL"

        End If

    End Sub

    'DBMS MARK,GRADE,RESULT'
    Private Sub DBMSTXT_Leave(sender As Object, e As System.EventArgs) Handles DBMSTXT.Leave

        Dim a As Integer
        a = DBMSTXT.Text

        If a >= 80 And a <= 100 Then

            DBMSTXT.Text = "A+"
            DBMSRESULTTXT.Text = "PASS"

        ElseIf (a >= 70 And a <= 79) Then

            DBMSTXT.Text = "A"
            DBMSRESULTTXT.Text = "PASS"

        ElseIf (a >= 60 And a <= 69) Then

            DBMSTXT.Text = "B"
            DBMSRESULTTXT.Text = "PASS"

        ElseIf a >= 50 And a <= 59 Then

            DBMSTXT.Text = "C"
            DBMSRESULTTXT.Text = "PASS"

        ElseIf a >= 40 And a <= 49 Then

            DBMSTXT.Text = "D"
            DBMSRESULTTXT.Text = "FAIL"

        End If

    End Sub

    'FOR FINAL GRADE AND RESULT'
    Private Sub TOTALTXT_Leave(sender As Object, e As System.EventArgs) Handles TOTALTXT.Leave

        Dim TOTAL As Integer = GRADETXT.Text

        If TOTAL >= 480 And TOTAL <= 600 Then

            GRADETXT.Text = "A+"
            RESULTTXT.Text = "PASS"

        ElseIf TOTAL >= 420 And TOTAL < +419 Then

            GRADETXT.Text = "A"
            RESULTTXT.Text = "PASS"

        ElseIf TOTAL >= 360 And TOTAL <= 359 Then

            GRADETXT.Text = "B"
            RESULTTXT.Text = "PASS"

        ElseIf TOTAL >= 300 And TOTAL <= 359 Then

            GRADETXT.Text = "C"
            RESULTTXT.Text = "PASS"

        ElseIf TOTAL >= 1 And TOTAL <= 299 Then

            GRADETXT.Text = "D"
            RESULTTXT.Text = "FAIL"

        End If

    End Sub

    'INSERT'
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "INSERT INTO MARKS VALUES('" & REGNUMTXT.Text & "','" & OSTXT.Text & "','" & VBTXT.Text & "','" & CATXT.Text & "','" & DBMSTXT.Text & "','" & GRADETXT.Text & "','" & RESULTTXT.Text & "')"
        cmd.ExecuteNonQuery()


    End Sub

    'UPDATE'
    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE MARKS SET OS='" & OSTXT.Text & "', VB= '" & VBTXT.Text & "', CA='" & CATXT.Text & "', DBMS='" & DBMSTXT.Text & "', GRADE='" & GRADETXT.Text & "', RESULT='" & RESULTTXT.Text & "')"
        cmd.ExecuteNonQuery()


    End Sub

    'DELETE'
    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click

    End Sub

    'CLEAR'
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

    End Sub

    'CLOSE'
    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click

    End Sub

   
End Class