﻿Imports System.Data.Sql
Imports System.Data.SqlClient


Public Class Form5

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    'PAYROLL PROCESSING FORM LOAD'
    Private Sub Form5_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        con.ConnectionString = ""
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()

        'DISABLING SAVE BUTTON'
        Button2.Enabled = False

    End Sub

    'EMPLOYEE ID LEAVE EVENT'
    Private Sub TextBox2_Leave(sender As System.Object, e As System.EventArgs) Handles EMPIDTXT.Leave

        'CHECKING IF EMP ID IS ALL NUMBERS OR NOT'
        If IsNumeric(EMPIDTXT.Text) = False Then

            MessageBox.Show("INVALID VALUE")
            EMPIDTXT.Clear()

        End If


        'FETCHING EMP NAME'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT EMPNAME FROM EMPINFO WHERE EMPID = " & EMPIDTXT.Text & ""
        NAMETXT.Text = CType(cmd.ExecuteScalar(), String)

        'FETCHING DESIGNATION'
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT DESIGNATION FROM EMPINFO WHERE EMPID = " & EMPIDTXT.Text & ""
        ComboBox1.SelectedItem = CType(cmd.ExecuteScalar(), String)

        'GENERATION OF BASIC PAY'
        If ComboBox1.SelectedItem = "MANAGER" Then

            BPAYTXT.Text = 60000

        ElseIf ComboBox1.SelectedItem = "CLERK" Then

            BPAYTXT.Text = 20000

        ElseIf ComboBox1.SelectedItem = "ADMINISTRATOR" Then

            BPAYTXT.Text = 30000

        ElseIf ComboBox1.SelectedItem = "EXECUTIVE" Then

            BPAYTXT.Text = 80000

        End If

        Dim BPAY As Integer = 0
        BPAY = BPAY + BPAYTXT.Text

        'CALCULATING ALLOWANCE'
        ALLOWTXT.Text = BPAY + ((BPAY * 10) / 100) 'HRA=10%'
        ALLOWTXT.Text = ALLOWTXT.Text + ((BPAY * 30) / 100) 'DA=30%'

        'CALCULATING DEDUCTION'
        DEDTXT.Text = BPAY - ((BPAY * 12) / 100) 'PF=12%'

    End Sub

    'CALCULATE BUTTON'
    Private Sub CALC_Click(sender As System.Object, e As System.EventArgs) Handles CALC.Click

        'CALCULATING GROSS PAY'
        GPAYTXT.Text = ALLOWTXT.Text + DEDTXT.Text

    End Sub

    'GPAY TEXTBOX ENTER'
    Private Sub TextBox1_Enter(sender As System.Object, e As System.EventArgs) Handles GPAYTXT.Enter

        'ENABLING SAVE BUTTON'
        Button2.Enabled = True

    End Sub

    'SAVE BUTTON'
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "INSERT INTO SALARYINFO VALUES('" & EMPIDTXT.Text & "','" & GPAYTXT.Text & "')"
        cmd.ExecuteNonQuery()

    End Sub

    'UPDATE BUTTON'
    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE EMPINFO SET EMPNAME ='" + NAMETXT.Text + "', DESIGNATION='" + ComboBox1.SelectedValue + "' WHERE EMPID='" & EMPIDTXT.Text & "'"
        cmd.ExecuteNonQuery()

    End Sub

    'DELETE BUTTON'
    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "DELETE FROM SALARYINFO WHERE EMPID = " & EMPIDTXT.Text & " "
        cmd.ExecuteNonQuery()

    End Sub

    'CLEAR BUTTON'
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        EMPIDTXT.Clear()
        NAMETXT.Clear()
        ComboBox1.SelectedIndex = -1
        BPAYTXT.Clear()
        ALLOWTXT.Clear()
        DEDTXT.Clear()
        GPAYTXT.Clear()

    End Sub

End Class