﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class Form1

    Dim con As New SqlConnection
    Dim cmd As New SqlCommand

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        con.ConnectionString = ""
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()


    End Sub

    'SEARCH BUTTON'
    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
       
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM STUDINFO WHERE ROLLNUM=" & ROLLNUMTXT.Text & ""
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    'FIRST NAME VALIDATION CHECK'
    Private Sub FNTXT_Leave(sender As Object, e As System.EventArgs) Handles FNTXT.Leave

        Dim NAME As String = FNTXT.Text

        If Char.IsLower(NAME(0)) Then

            Char.ToUpper(NAME(0))

        End If
        FNTXT.Text = NAME

    End Sub

    'SECOND NAME VALIDATION CHECK'
    Private Sub LNTXT_Leave(sender As Object, e As System.EventArgs) Handles LNTXT.Leave

        Dim NAME As String = LNTXT.Text

        If Char.IsLower(NAME(0)) Then

            Char.ToUpper(NAME(0))

        End If
        LNTXT.Text = NAME

    End Sub

    'INSERT '
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "INSERT INTO STUDINFO VALUES('" & ROLLNUMTXT.Text & "','" + (FNTXT.Text + LNTXT.Text) + "','" + ComboBox1.SelectedItem + "')"
        cmd.ExecuteNonQuery()


    End Sub

    'DELETE'
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "DELETE  FROM STUDINFO WHERE ROLLNUM=" & ROLLNUMTXT.Text & ""
        cmd.ExecuteNonQuery()

    End Sub

    'UPDATE'
    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "UPDATE STUDINFO SET NAME='" + (FNTXT.Text + LNTXT.Text) + "', DEPARTMENT ='" + ComboBox1.SelectedItem + "')"
        cmd.ExecuteNonQuery()


    End Sub

    'CLEAR'
    Private Sub CLEAR_Click(sender As System.Object, e As System.EventArgs) Handles CLEAR.Click

    End Sub

End Class
