﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ALLOWTXT = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DEDTXT = New System.Windows.Forms.TextBox()
        Me.CALC = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.EMPIDTXT = New System.Windows.Forms.TextBox()
        Me.GPAYTXT = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.UsernameLabel = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BPAYTXT = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.NAMETXT = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(542, 19)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(360, 36)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "PAYROLL PROCESSING"
        '
        'ALLOWTXT
        '
        Me.ALLOWTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.ALLOWTXT.Location = New System.Drawing.Point(211, 114)
        Me.ALLOWTXT.Name = "ALLOWTXT"
        Me.ALLOWTXT.ReadOnly = True
        Me.ALLOWTXT.Size = New System.Drawing.Size(214, 28)
        Me.ALLOWTXT.TabIndex = 32
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label5.Location = New System.Drawing.Point(17, 110)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(213, 48)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "ALLOWANCE"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DEDTXT
        '
        Me.DEDTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.DEDTXT.Location = New System.Drawing.Point(211, 197)
        Me.DEDTXT.Name = "DEDTXT"
        Me.DEDTXT.ReadOnly = True
        Me.DEDTXT.Size = New System.Drawing.Size(214, 30)
        Me.DEDTXT.TabIndex = 30
        '
        'CALC
        '
        Me.CALC.BackColor = System.Drawing.Color.LightGray
        Me.CALC.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.CALC.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CALC.Location = New System.Drawing.Point(211, 253)
        Me.CALC.Name = "CALC"
        Me.CALC.Size = New System.Drawing.Size(214, 40)
        Me.CALC.TabIndex = 28
        Me.CALC.Text = "CALCULATE"
        Me.CALC.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label3.Location = New System.Drawing.Point(17, 188)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(181, 48)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "DEDUCTION"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'EMPIDTXT
        '
        Me.EMPIDTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.EMPIDTXT.Location = New System.Drawing.Point(265, 47)
        Me.EMPIDTXT.MaxLength = 5
        Me.EMPIDTXT.Name = "EMPIDTXT"
        Me.EMPIDTXT.Size = New System.Drawing.Size(214, 30)
        Me.EMPIDTXT.TabIndex = 26
        '
        'GPAYTXT
        '
        Me.GPAYTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.GPAYTXT.Location = New System.Drawing.Point(264, 50)
        Me.GPAYTXT.Name = "GPAYTXT"
        Me.GPAYTXT.ReadOnly = True
        Me.GPAYTXT.Size = New System.Drawing.Size(214, 30)
        Me.GPAYTXT.TabIndex = 25
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label1.Location = New System.Drawing.Point(37, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(197, 48)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "EMPLOYEE ID"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'UsernameLabel
        '
        Me.UsernameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.UsernameLabel.Location = New System.Drawing.Point(79, 41)
        Me.UsernameLabel.Name = "UsernameLabel"
        Me.UsernameLabel.Size = New System.Drawing.Size(179, 48)
        Me.UsernameLabel.TabIndex = 23
        Me.UsernameLabel.Text = "GROSS PAY"
        Me.UsernameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"MANAGER", "CLERK", "ADMINISTRATOR", "EXECUTIVE"})
        Me.ComboBox1.Location = New System.Drawing.Point(263, 201)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(216, 28)
        Me.ComboBox1.TabIndex = 33
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label2.Location = New System.Drawing.Point(37, 190)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(197, 48)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "DESIGNATION"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'BPAYTXT
        '
        Me.BPAYTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.BPAYTXT.Location = New System.Drawing.Point(211, 43)
        Me.BPAYTXT.Name = "BPAYTXT"
        Me.BPAYTXT.ReadOnly = True
        Me.BPAYTXT.Size = New System.Drawing.Size(214, 28)
        Me.BPAYTXT.TabIndex = 36
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label6.Location = New System.Drawing.Point(17, 32)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(171, 48)
        Me.Label6.TabIndex = 35
        Me.Label6.Text = "BASIC PAY"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label7.Location = New System.Drawing.Point(485, 114)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(249, 37)
        Me.Label7.TabIndex = 37
        Me.Label7.Text = "HRA=10%  DA  =30%" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label8.Location = New System.Drawing.Point(485, 188)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(152, 48)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "PF=12%"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DarkGray
        Me.Button1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(1037, 595)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(183, 53)
        Me.Button1.TabIndex = 39
        Me.Button1.Text = "CLEAR"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.DarkGray
        Me.Button2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(292, 595)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(183, 53)
        Me.Button2.TabIndex = 40
        Me.Button2.Text = "SAVE"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'NAMETXT
        '
        Me.NAMETXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.NAMETXT.Location = New System.Drawing.Point(265, 119)
        Me.NAMETXT.MaxLength = 5
        Me.NAMETXT.Name = "NAMETXT"
        Me.NAMETXT.Size = New System.Drawing.Size(214, 30)
        Me.NAMETXT.TabIndex = 42
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label9.Location = New System.Drawing.Point(37, 114)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(226, 48)
        Me.Label9.TabIndex = 41
        Me.Label9.Text = "EMPLOYEE NAME"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.DarkGray
        Me.Button3.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Button3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button3.Location = New System.Drawing.Point(527, 595)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(183, 53)
        Me.Button3.TabIndex = 43
        Me.Button3.Text = "UPDATE"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.DarkGray
        Me.Button4.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Button4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button4.Location = New System.Drawing.Point(777, 595)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(183, 53)
        Me.Button4.TabIndex = 44
        Me.Button4.Text = "DELETE"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PowderBlue
        Me.Panel1.Controls.Add(Me.NAMETXT)
        Me.Panel1.Controls.Add(Me.EMPIDTXT)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.ComboBox1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(84, 77)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(539, 312)
        Me.Panel1.TabIndex = 45
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.BPAYTXT)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.ALLOWTXT)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.DEDTXT)
        Me.Panel2.Controls.Add(Me.CALC)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Location = New System.Drawing.Point(672, 77)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(770, 307)
        Me.Panel2.TabIndex = 46
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Panel3.Controls.Add(Me.GPAYTXT)
        Me.Panel3.Controls.Add(Me.UsernameLabel)
        Me.Panel3.Location = New System.Drawing.Point(84, 416)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(543, 139)
        Me.Panel3.TabIndex = 47
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(672, 416)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(770, 139)
        Me.DataGridView1.TabIndex = 26
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1560, 674)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form5"
        Me.Text = "Form5"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ALLOWTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents DEDTXT As System.Windows.Forms.TextBox
    Friend WithEvents CALC As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents EMPIDTXT As System.Windows.Forms.TextBox
    Friend WithEvents GPAYTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents UsernameLabel As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents BPAYTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents NAMETXT As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
End Class
